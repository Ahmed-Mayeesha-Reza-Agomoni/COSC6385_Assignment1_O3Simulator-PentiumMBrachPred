GitHub repository link: https://github.com/Ahmed-Mayeesha-Reza-Agomoni/COSC6385_Assignment1_O3Simulator-PentiumMBrachPred
The run command is visible in the result.png image