// my_predictor.h
// This file contains a sample gshare_predictor class.
// It is a simple 32,768-entry gshare with a history length of 15.

class gshare_update : public branch_update {
public:
	unsigned int index;
};

class gshare_predictor : public branch_predictor {
public:
#define HISTORY_LENGTH	15
#define TABLE_BITS	15
	gshare_update u;
	branch_info bi;
	unsigned int history;
	unsigned char tab[1<<TABLE_BITS];

	gshare_predictor (void) : history(0) { 
		memset (tab, 0, sizeof (tab));
	}

	branch_update *predict (branch_info & b) {
		bi = b;
		if (b.br_flags & BR_CONDITIONAL) {
			u.index = 
				  (history << (TABLE_BITS - HISTORY_LENGTH)) 
				^ (b.address & ((1<<TABLE_BITS)-1));
			u.direction_prediction (tab[u.index] >> 1);
		} else {
			u.direction_prediction (true);
		}
		u.target_prediction (0);
		return &u;
	}

	void update (branch_update *u, bool taken, unsigned int target) {
		if (bi.br_flags & BR_CONDITIONAL) {
			unsigned char *c = &tab[((gshare_update*)u)->index];
			if (taken) {
				if (*c < 3) (*c)++;
			} else {
				if (*c > 0) (*c)--;
			}
			history <<= 1;
			history |= taken;
			history &= (1<<HISTORY_LENGTH)-1;
		}
	}
};

//
// Pentium M hybrid branch predictors
// This class implements a simple hybrid branch predictor based on the Pentium M branch outcome prediction units. 
// Instead of implementing the complete Pentium M branch outcome predictors, the class below implements a hybrid 
// predictor that combines a bimodal predictor and a global predictor. 
class pm_update : public branch_update {
public:
        //unsigned int index;
		unsigned int bim_index;   // which bimodal counter we used
        unsigned int set;         // which row of the global table we looked in
        unsigned int tag;         // the tag we searched for
        int hit_way;              // which way matched (0 or 1) or -1 if none
        bool used_global;         // not actually used by update() so we can delete
};

class pm_predictor : public branch_predictor {
public:
#define PM_BIM_BITS 12   //bimodal table has 2^12 = 4096 counters
#define PM_HIST_BITS 15   //remember the last 15 outcomes (instead of PIR)
#define PM_SET_BITS 9    //global table has 2^9 = 512 rows/set
#define PM_TAG_BITS 6    //tag has 6 bits 
#define PM_WAYS 2    //each set has 2 entries/2-way associative
        pm_update u;
		branch_info bi; //remembers the current branch for update() to see its flags
		unsigned int history; //global history register -> last 15 outcomes

		// BIMODAL TABLE: 4096 counters-> each 0..3.
        //indexed only by the branch's address. Learns "is THIS branch usually taken?"
        unsigned char bimodal[1 << PM_BIM_BITS];

        // One slot in the global table:
        struct entry {
                bool valid;          // has this slot been filled yet?
                unsigned char tag;   // identifies WHICH (address, history) combo owns the slot
                unsigned char ctr;   // 2-bit counter: its prediction
        };

        // GLOBAL TABLE: 512 sets x 2 ways = 1024 entries.
        entry global[1 << PM_SET_BITS][PM_WAYS];

        // One bit per set: which of the 2 ways is LEAST recently used.
        // When a set is full, we replace that way in update()
        unsigned char lru[1 << PM_SET_BITS];

        pm_predictor (void) : history(0){
			memset (bimodal, 1, sizeof (bimodal));  // every counter starts at 1 = "weakly not taken"->look at the FSM diagram
            memset (global, 0, sizeof (global));    // valid=false everywhere so the table is empty
            memset (lru, 0, sizeof (lru));          // arbitrary starting LRU
        }

        // branch_update *predict (branch_info & b) {
			
		// 	// predict branch outcome
        //     u.direction_prediction (true);
			
		// 	// predict branch target address
        //     u.target_prediction (0);
            
		// 	return &u;
        // }
		branch_update *predict (branch_info & b) {
			bi = b;                 //save the branch info for update() later
			u.hit_way = -1;         // default: no global hit yet
			u.used_global = false;

			if (b.br_flags & BR_CONDITIONAL) {   // only conditional branches are predicted
													// (jumps/calls are always taken)

					//BIMODAL  index = IP[11:0])
					//Keep the low 12 bits of the address -> a number from 0 to 4095
					u.bim_index = b.address & ((1 << PM_BIM_BITS) - 1);
					// Counter >> 1 is 1 when the counter is 2 or 3, i.e. "taken"
					bool bim_pred = bimodal[u.bim_index] >> 1;

					//GLOBAL
					// HASH = address XOR history.  Same address + different recent
					//outcomes -> different hash -> different table entry, so one branch
					//can have different predictions in different contexts.
					unsigned int hash = (b.address & 0x7FFF) ^ history;

					//index (set) = HASH[14:6]  -> shift out the low 6 bits, keep 9 bits
					//tag = HASH[5:0]   -> the low 6 bits
					u.set = (hash >> PM_TAG_BITS) & ((1 << PM_SET_BITS) - 1);
					u.tag = hash & ((1 << PM_TAG_BITS) - 1);

					//Looking in both ways of that set for a valid entry with our tag.
					//The tags are what guard against two different (address, history)
					// pairs landing in the same set and sharing a counter by mistake.
					for (int w = 0; w < PM_WAYS; w++) {
							if (global[u.set][w].valid && global[u.set][w].tag == u.tag) {
									u.hit_way = w;   //remember where we hit
									break;           // stop searching as we are done
							}
					}

					//Final MUX -> the selector at the bottom right
					if (u.hit_way >= 0) {
							//Global HIT: trust the global predictor
							u.used_global = true;
							u.direction_prediction (global[u.set][u.hit_way].ctr >> 1);
					} else {
							//Global MISS: fall back to the bimodal predictor
							u.direction_prediction (bim_pred);
					}
			} else {
					u.direction_prediction (true);   //non-conditional branches: always taken
			}

			u.target_prediction (0);   //target prediction (BTB) is not required so 0
			return &u;                 //handing the note back to the simulator
	}
		

		void update (branch_update *bu, bool taken, unsigned int target) {
		if (!(bi.br_flags & BR_CONDITIONAL)) return;   //only train on conditional branches
		pm_update *pu = (pm_update *) bu;               //cast back to our own note type

		//Train the bimodal counter (always)
		// Saturating counter: taken -> up (max 3); not taken -> down (min 0).
		unsigned char *c = &bimodal[pu->bim_index];     //pointer to that counter
		if (taken) { if (*c < 3) (*c)++; }
		else       { if (*c > 0) (*c)--; }

		//Train the global table ----
		if (pu->hit_way >= 0) {
				//We had a hit so we nudge that entry's counter toward the real outcome
				unsigned char *g = &global[pu->set][pu->hit_way].ctr;
				if (taken) { if (*g < 3) (*g)++; }
				else       { if (*g > 0) (*g)--; }
				//The way we just used is now most recent so the OTHER way is LRU
				lru[pu->set] = 1 - pu->hit_way;
		} else {
				//We missed: install a new entry for this (address, history) context.
				int victim = lru[pu->set];           //default victim: the LRU way
				for (int w = 0; w < PM_WAYS; w++) {
						// But if a way is still empty, use that instead
						if (!global[pu->set][w].valid) { victim = w; break; }
				}
				global[pu->set][victim].valid = true;
				global[pu->set][victim].tag = pu->tag;
				//Start the counter "weak" in the direction of what just happened:
				//2 = weakly taken, 1 = weakly not taken
				global[pu->set][victim].ctr = taken ? 2 : 1;
				//The way we just filled is most recent so the other is LRU
				lru[pu->set] = 1 - victim;
		}

		//Update the history register
		//Shift left by 1, put the new outcome in the lowest bit, then trim to
		//15 bits. This is how "the last 15 outcomes" slides forward.
		history = ((history << 1) | taken) & ((1 << PM_HIST_BITS) - 1);
}

};

//
// Complete Pentium M branch predictors for extra credit
// This class implements the complete Pentium M branch prediction units. 
// It implements both branch target prediction and branch outcome predicton. 
class cpm_update : public branch_update {
public:
        unsigned int index;
};

class cpm_predictor : public branch_predictor {
public:
        cpm_update u;

        cpm_predictor (void) {
        }

        branch_update *predict (branch_info & b) {
            u.direction_prediction (true);
            u.target_prediction (0);
            return &u;
        }

        void update (branch_update *u, bool taken, unsigned int target) {
        }

};


