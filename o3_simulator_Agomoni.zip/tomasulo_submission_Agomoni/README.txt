GitHub repository link: https://github.com/Ahmed-Mayeesha-Reza-Agomoni/COSC6385_Assignment1_O3Simulator-PentiumMBrachPred
RUN:

    python main.py INPUT_FILE                  #issue width from the file ("Issue width = N", default 1)
    python main.py INPUT_FILE --issue-width 4  #override the width which is 1 to 4

Output: the instruction table (ISSUE, EX, MEM, WB, COMMIT) then "REGISTER VALUES" and "NON-ZERO MEMORY VALUES"

Input File:

    # of rs / Cycles in EX / Cycles in Mem / # of FUs        (header line is ignored)
    Integer adder   4   1         1
    FP adder        3   4         1
    FP multiplier   2   15        1
    Load/store unit 5   1   5     1
    ROB entries = 64
    Issue width = 2                       (optional, 1 to 4, default 1)
    Branch offset = words                 (optional: words | bytes | auto, default auto)
    R1=12, R2=32, F20=3.0
    Mem[4]=3.0, Mem[8]=2.0

    Ld F2 0(R1)
    Bne R1 R0 -12

Case does not matter. Blank lines and lines starting with `#` are ignored.
Branch offsets: "words" = number of instructions 
"bytes"= already multiplied by 4 ("test_case.txt", "-12");
"auto" = words unless that target is outside the program and the offset is a
multiple of 4 and then bytes.

Command:

    python run_tests.py

Runs every file in the "tests/" folder at issue widths 1, 2, 3 and 4. The final registers and memory of every run are compared with a simple in-order interpreter. It then prints the cycle count table. Expected last line: "0 failures"



