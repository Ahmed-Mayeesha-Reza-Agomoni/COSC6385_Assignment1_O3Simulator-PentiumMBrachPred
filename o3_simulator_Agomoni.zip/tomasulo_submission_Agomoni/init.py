# Qing 
# 21st May 2017 

# from collections import namedtuple

# '''define data types'''
# # reservation station 
# def rs_entry():
#     rs_entry = namedtuple('rs_entry', 'busy, op, tag_1st, value_1st, valid_1st, tag_2nd, value_2nd, valid_2nd, dest_tag')
#     temp = rs_entry
#     return temp 
# # functional unit 
# def fu_entry():
#     fu_entry = namedtuple('fu_entry', 'cycle, op, value1, value2, dest_tag')
#     temp = fu_entry
#     return temp
# # function result 
# def fu_result():
#     fu_result = namedtuple('fu_result', 'value, dest_tag')
#     temp = fu_result
#     return temp
# # ld/sd entry
# def ld_sd_entry():
#     ld_sd_entry = namedtuple('ld_sd_entry', 'ld_sd_tag, ready, op, address, data, dest_tag, immediate, reg_tag, reg_value, valid')
#     temp = ld_sd_entry
#     return temp
# # ld/sd exe
# def ld_sd_exe():
#     ld_sd_exe = namedtuple('ld_sd_exe', 'busy, cycle, value1, value2, dest_tag')
#     temp = ld_sd_exe
#     return temp
# # ld/sd mem
# def ld_sd_mem():
#     ld_sd_mem = namedtuple('ld_sd_mem', 'busy, cycle, op, data, address, dest_tag')
#     temp = ld_sd_mem
#     return temp
# # cdb
# def cdb():
#     cdb = namedtuple('cdb', 'valid, value, dest_tag')
#     temp = cdb
#     return temp
# # ROB_entry 
# def ROB_entry():
#     ROB_entry = namedtuple('ROB_entry', 'ROB_tag, PC, value, dest_tag, issue, exe, mem, cdb, commit')
#     temp = ROB_entry
#     temp.issue = []
#     temp.exe = []
#     temp.mem = []
#     temp.cdb = []
#     temp.commit =[]
#     return temp
# # PC 
# def PC():
#     PC = namedtuple('PC', 'PC, valid')
#     temp = PC
#     return temp


# Reservation station
class rs_entry:
    def __init__(self):
        self.busy = 0
        self.op = ''
        self.tag_1st = None
        self.value_1st = 0
        self.valid_1st = 0
        self.tag_2nd = None
        self.value_2nd = 0
        self.valid_2nd = 0
        self.dest_tag = None

# Functional unit
class fu_entry:
    def __init__(self):
        self.cycle = 0
        self.op = ''
        self.value1 = 0
        self.value2 = 0
        self.dest_tag = None

# Function result
class fu_result:
    def __init__(self):
        self.value = 0
        self.dest_tag = None

# Load/store entry
class ld_sd_entry:
    def __init__(self):
        self.ld_sd_tag = None
        self.ready = 0
        self.op = ''
        self.address = 0
        self.data = 0
        self.dest_tag = None
        self.immediate = 0
        self.reg_tag = None
        self.reg_value = 0
        self.valid = 0

# Load/store execution unit
class ld_sd_exe:
    def __init__(self):
        self.busy = 0
        self.cycle = 0
        self.value1 = 0
        self.value2 = 0
        self.dest_tag = None

# Load/store memory unit
class ld_sd_mem:
    def __init__(self):
        self.busy = 0
        self.cycle = 0
        self.op = ''
        self.data = 0
        self.address = 0
        self.dest_tag = None

# CDB
class cdb:
    def __init__(self):
        self.valid = 0
        self.value = 0
        self.dest_tag = None

# Reorder buffer entry
class ROB_entry:
    def __init__(self):
        self.ROB_tag = None
        self.PC = None
        self.value = 0
        self.dest_tag = None
        self.issue = []
        self.exe = []
        self.mem = []
        self.cdb = []
        self.commit = []

# Program counter
class PC:
    def __init__(self):
        self.PC = 0
        self.valid = 1

# function: read instructions
def read_instruction(codefile):
    with open(codefile) as f:
            instructions = f.read().splitlines()
    return instructions
# function: build rs
def build_rs(num):
    rs = []
    for _ in range(num):
        temp = rs_entry()
        temp.busy = 0
        rs.extend([temp])
    return rs


#Branch Target Buffer (BTB)
#8 entries, with a 1-bit direction predictor.
BTB_SIZE = 8


def build_btb():
    btb = []
    for _ in range(BTB_SIZE):
        btb.append({
            'valid': False,
            'branch_pc': None,
            'target_pc': None,
            'predicted_taken': False
        })
    return btb


def btb_index(pc):
    return pc & (BTB_SIZE - 1)



# ---------------------------------------------------------------------------
# NEW (assignment: input file format)
# Reads ONE input file: configuration table, "ROB entries", "Issue width",
# initial R/F registers, Mem[..] values, and then the instructions.
# Everything is case-insensitive; blank lines and lines starting with '#' are
# skipped. Missing items get defaults (issue width 1, ROB 64, zero registers).
# ---------------------------------------------------------------------------
import re

MEM_SIZE = 256   # bytes
# canonical spelling of every opcode (so "ld", "LD" and "Ld" all work)
_OPCODES = {'ld': 'Ld', 'sd': 'Sd', 'add': 'Add', 'add.d': 'Add.d',
            'addi': 'Addi', 'sub': 'Sub', 'sub.d': 'Sub.d',
            'mult.d': 'Mult.d', 'bne': 'Bne', 'beq': 'Beq'}
_UNIT_LABELS = (('integer adder', 'int_adder'), ('fp adder', 'fp_adder'),
                ('fp multiplier', 'fp_multi'), ('load/store unit', 'ld_sd'))
_NUM = r'[-+]?\d+(?:\.\d*)?(?:[eE][-+]?\d+)?'


class InputFile:
    """What read_input() returns."""
    def __init__(self):
        # (# rs, cycles in EX, cycles in Mem, # FUs); Mem is None for ALUs
        self.config = {'int_adder': (4, 1, None, 1), 'fp_adder': (3, 4, None, 1),
                       'fp_multi': (2, 15, None, 1), 'ld_sd': (5, 1, 5, 1)}
        self.rob_entries = 64
        self.issue_width = 1
        self.branch_offset = 'auto'      # 'words' | 'bytes' | 'auto'
        self.reg_int = [0] * 32
        self.reg_fp = [0.0] * 32
        self.memory = [0.0] * MEM_SIZE
        self.instructions = []           # text lines, opcode in canonical case


def read_input(path):
    inp = InputFile()
    with open(path) as f:
        lines = f.read().splitlines()
    for raw in lines:
        line = raw.strip()
        if not line or line.startswith('#'):
            continue
        low = line.lower()
        # configuration table row
        unit = next((k for lab, k in _UNIT_LABELS if low.startswith(lab)), None)
        if unit:
            lab = next(l for l, k in _UNIT_LABELS if k == unit)
            nums = [int(x) for x in re.findall(r'\d+', line[len(lab):])]
            if unit == 'ld_sd':
                if len(nums) != 4:
                    raise ValueError('need 4 numbers on: ' + line)
                inp.config[unit] = (nums[0], nums[1], nums[2], nums[3])
            else:
                if len(nums) != 3:
                    raise ValueError('need 3 numbers on: ' + line)
                inp.config[unit] = (nums[0], nums[1], None, nums[2])
            continue
        # single-value settings
        m = re.match(r'^(rob entries|issue width)\s*=\s*(\d+)$', low)
        if m:
            if m.group(1) == 'rob entries':
                inp.rob_entries = int(m.group(2))
            else:
                inp.issue_width = int(m.group(2))
            continue
        m = re.match(r'^branch offset\s*=\s*(words|bytes|auto)$', low)
        if m:
            inp.branch_offset = m.group(1)
            continue
        # initial registers / memory, e.g.  R1=12, R2=32, F20=3.0   Mem[4]=3.0
        if '=' in line:
            found = False
            for m in re.finditer(r'\b([RF])(\d+)\s*=\s*(' + _NUM + ')', line, re.I):
                n = int(m.group(2))
                if n > 31:
                    raise ValueError('no such register: ' + m.group(0))
                if m.group(1).upper() == 'R':
                    if n != 0:                      # R0 is always 0
                        inp.reg_int[n] = int(float(m.group(3)))
                else:
                    inp.reg_fp[n] = float(m.group(3))
                found = True
            for m in re.finditer(r'mem\[\s*(\d+)\s*\]\s*=\s*(' + _NUM + ')', line, re.I):
                addr = int(m.group(1))
                if addr >= MEM_SIZE:
                    raise ValueError('address outside memory: ' + m.group(0))
                inp.memory[addr] = float(m.group(2))
                found = True
            if not found:
                raise ValueError('cannot read the line: ' + line)
            continue
        # otherwise an instruction
        op, _, rest = line.partition(' ')
        if op.lower() not in _OPCODES:
            raise ValueError('unknown instruction: ' + line)
        inp.instructions.append((_OPCODES[op.lower()] + ' ' + rest.strip()).strip())
    if not 1 <= inp.issue_width <= 4:
        raise ValueError('Issue width must be 1..4')
    if inp.rob_entries < 1:
        raise ValueError('ROB entries must be at least 1')
    return inp
