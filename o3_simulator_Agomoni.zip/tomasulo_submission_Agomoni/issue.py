
# Qing
# 21st May 2017

"""
1. Put one instruction in the ROB.
2. Put this instruction in an RS or the LSQ.
3. Update the RAT.
"""

from init import ld_sd_entry, ROB_entry, btb_index


def _tokens(ins):
    """Split an instruction, ignoring comments and optional commas."""
    return ins.split("#", 1)[0].replace(",", " ").split()


def _register_value(register, rat_int, rat_fp):
    """Return a register's current value or its pending ROB tag."""
    register = register.upper()

    if len(register) < 2 or register[0] not in ("R", "F"):
        raise ValueError(f"Invalid register: {register}")

    try:
        index = int(register[1:])
    except ValueError as exc:
        raise ValueError(f"Invalid register: {register}") from exc

    if not 0 <= index < 32:
        raise ValueError(f"Register index out of range: {register}")

    return rat_int[index] if register[0] == "R" else rat_fp[index]


def _set_operand(entry, operand_number, operand, rat_int, rat_fp):
    """Set an RS operand from a register or integer immediate."""
    if operand.lstrip("+-").isdigit():
        value = int(operand)
    else:
        value = _register_value(operand, rat_int, rat_fp)

    if isinstance(value, str):
        tag, operand_value, valid = value, 0, 0
    else:
        tag, operand_value, valid = None, value, 1

    if operand_number == 1:
        entry.tag_1st = tag
        entry.value_1st = operand_value
        entry.valid_1st = valid
    else:
        entry.tag_2nd = tag
        entry.value_2nd = operand_value
        entry.valid_2nd = valid


def _reset_rs_entry(entry):
    """Clear old operand data when a reservation station is reused."""
    entry.busy = 0
    entry.op = None
    entry.tag_1st = None
    entry.value_1st = 0
    entry.valid_1st = 0
    entry.tag_2nd = None
    entry.value_2nd = 0
    entry.valid_2nd = 0
    entry.dest_tag = None


# Find a free tag for an LSQ entry.
def find_tag_new_ldsd_entry(ld_sd_queue, size_ld_sd_queue):
    existing_tags = {entry.ld_sd_tag for entry in ld_sd_queue}

    for i in range(size_ld_sd_queue):
        tag = "ldsd" + str(i)
        if tag not in existing_tags:
            return tag

    raise RuntimeError("No free LSQ tag is available.")


# Put an instruction into the ROB.
def put_ins_into_ROB(ROB, size_ROB, PC, cycle, ins, ldsd_tag):
    if len(ROB) >= size_ROB:
        raise RuntimeError("Cannot add instruction: ROB is full.")

    tokens = _tokens(ins)
    op = tokens[0].lower()

    entry = ROB_entry()

    # if not ROB:
    #     entry.ROB_tag = "ROB0"
    # else:
    #     index = int(ROB[-1].ROB_tag[3:])
    #     entry.ROB_tag = "ROB" + str((index + 1) % size_ROB)
    existing_tags = {item.ROB_tag for item in ROB}
    for index in range(size_ROB):
        candidate = "ROB" + str(index)
        if candidate not in existing_tags:
            entry.ROB_tag = candidate
            break
    else:
        raise RuntimeError("No free ROB tag is available.")

    entry.PC = PC.PC

    if op == "sd":
        entry.dest_tag = ldsd_tag
    elif op in ("bne", "beq"):
        entry.dest_tag = int(tokens[-1])
    else:
        if len(tokens) < 2:
            raise ValueError(f"Missing destination register: {ins}")
        entry.dest_tag = tokens[1].upper()

    entry.issue.append(cycle)
    ROB.append(entry)


# Put an arithmetic instruction into a reservation station.
def put_ins_into_rs(station, index, ins, ROB, rat_int, rat_fp):
    tokens = _tokens(ins)
    op = tokens[0].lower()

    if len(tokens) != 4:
        raise ValueError(f"Expected three operands: {ins}")

    entry = station[index]
    _reset_rs_entry(entry)

    entry.busy = 1
    entry.op = {
        "add": "Add",
        "addi": "Addi",
        "sub": "Sub",
        "add.d": "Add.d",
        "sub.d": "Sub.d",
        "mult.d": "Mult.d",
    }[op]

    _set_operand(entry, 1, tokens[2], rat_int, rat_fp)
    _set_operand(entry, 2, tokens[3], rat_int, rat_fp)
    entry.dest_tag = ROB[-1].ROB_tag


# Put a branch into an integer reservation station.
def put_bne_into_rs(rs_int_adder, index, ins, rat_int, rat_fp, ROB):
    tokens = _tokens(ins)
    op = tokens[0].lower()

    if op not in ("beq", "bne") or len(tokens) != 4:
        raise ValueError(f"Invalid branch instruction: {ins}")

    entry = rs_int_adder[index]
    _reset_rs_entry(entry)

    entry.busy = 1
    entry.op = "Beq" if op == "beq" else "Bne"

    _set_operand(entry, 1, tokens[1], rat_int, rat_fp)
    _set_operand(entry, 2, tokens[2], rat_int, rat_fp)
    entry.dest_tag = ROB[-1].ROB_tag


# Put a load/store instruction into the LSQ.
def put_ins_into_ldsd(ldsd_tag, ld_sd_queue, ins, ROB, rat_int, rat_fp):
    tokens = _tokens(ins)
    op = tokens[0].lower()

    if op not in ("ld", "sd") or len(tokens) != 3:
        raise ValueError(f"Invalid load/store instruction: {ins}")

    data_register = tokens[1].upper()
    data_value = _register_value(data_register, rat_int, rat_fp)

    if data_register[0] != "F":
        raise ValueError(
            f"Load/store data register must be an FP register: {data_register}"
        )

    # Accept offsets such as 0(R1), -12(R2), and +8(R3).
    import re
    match = re.fullmatch(r"([+-]?\d+)\((R\d+)\)", tokens[2].upper())

    if match is None:
        raise ValueError(
            f"Invalid memory operand {tokens[2]!r}; expected format like 8(R2)"
        )

    immediate = int(match.group(1))
    base_register = match.group(2)
    base_value = _register_value(base_register, rat_int, rat_fp)

    entry = ld_sd_entry()
    entry.ld_sd_tag = ldsd_tag
    entry.ready = 0
    entry.op = "Ld" if op == "ld" else "Sd"
    entry.address = None
    entry.immediate = immediate
    entry.dest_tag = ROB[-1].ROB_tag

    if isinstance(base_value, str):
        entry.reg_tag = base_value
        entry.reg_value = 0
        entry.valid = 0
    else:
        entry.reg_tag = None
        entry.reg_value = base_value
        entry.valid = 1

    if op == "sd":
        # A string value means the store data is waiting for a producer.
        entry.data = data_value
    else:
        entry.data = None

    ld_sd_queue.append(entry)


# Check whether a reservation station is available.
def check_rs_space(station):
    for i, entry in enumerate(station):
        if entry.busy == 0:
            return i
    return -1


# Update the RAT for a register-producing instruction.
def update_rat(ROB, rat_int, rat_fp):
    if not ROB:
        return

    destination = ROB[-1].dest_tag

    # Branch offsets and LSQ tags are not register destinations.
    if not isinstance(destination, str):
        return

    if len(destination) < 2 or destination[0] not in ("F", "R"):
        return

    index = int(destination[1:])

    if destination[0] == "F":
        rat_fp[index] = ROB[-1].ROB_tag
    elif index != 0:
        # R0 is hardwired to zero and must never be renamed.
        rat_int[index] = ROB[-1].ROB_tag


# How the branch offset in the input file is written:
#   'words' : as in the handout. Target = PC + 4 + (offset << 2) bytes, so the
#             offset counts instructions ("Bne R2, R3, -3" jumps back 3).
#   'bytes' : the offset is already multiplied by 4 (the course test_case.txt
#             writes "Bne R1 R0 -12" for a jump back of 3 instructions).
#   'auto'  : words, unless that target lies outside the program and the offset
#             is a multiple of 4; then bytes. (The two files above need this.)
# main.py can set this from the input file ("Branch offset = words|bytes").
BRANCH_OFFSET_UNITS = 'auto'


def _branch_target(branch_pc, offset, num_instructions):
    """Instruction index that a taken branch at branch_pc jumps to."""
    in_words = branch_pc + 1 + offset
    in_bytes = branch_pc + 1 + offset // 4

    if BRANCH_OFFSET_UNITS == 'words':
        return in_words
    if BRANCH_OFFSET_UNITS == 'bytes':
        return in_bytes

    # auto
    if 0 <= in_words <= num_instructions:
        return in_words
    if offset % 4 == 0 and 0 <= in_bytes <= num_instructions:
        return in_bytes
    return in_words


def _issue_one(
    cycle, PC, instructions, ROB, size_ROB,
    rs_int_adder, rs_fp_adder, rs_fp_multi,
    ld_sd_queue, size_ld_sd_queue, rat_int, rat_fp,
    BTB=None, branch_predictions=None
):
    """Attempt to issue the instruction at PC.PC. Return True if issued."""
    if PC.PC < 0 or PC.PC >= len(instructions):
        PC.valid = 0
        return False

    tokens = _tokens(instructions[PC.PC])
    if not tokens:
        raise ValueError(f"Empty instruction at PC {PC.PC}")

    ins = " ".join(tokens)
    op = tokens[0].lower()

    if len(ROB) >= size_ROB:
        return False

    # Load/store instructions.
    if op in ("ld", "sd"):
        if len(ld_sd_queue) >= size_ld_sd_queue:
            return False

        ldsd_tag = find_tag_new_ldsd_entry(
            ld_sd_queue, size_ld_sd_queue
        )
        put_ins_into_ROB(ROB, size_ROB, PC, cycle, ins, ldsd_tag)
        put_ins_into_ldsd(
            ldsd_tag, ld_sd_queue, ins, ROB, rat_int, rat_fp
        )

        # Loads produce a register value; stores do not.
        if op == "ld":
            update_rat(ROB, rat_int, rat_fp)

        PC.PC += 1
        return True

    # Integer arithmetic.
    if op in ("add", "addi", "sub"):
        index = check_rs_space(rs_int_adder)
        if index < 0:
            return False

        put_ins_into_ROB(ROB, size_ROB, PC, cycle, ins, "")
        put_ins_into_rs(
            rs_int_adder, index, ins, ROB, rat_int, rat_fp
        )
        update_rat(ROB, rat_int, rat_fp)
        PC.PC += 1
        return True

    # FP addition/subtraction.
    if op in ("add.d", "sub.d"):
        index = check_rs_space(rs_fp_adder)
        if index < 0:
            return False

        put_ins_into_ROB(ROB, size_ROB, PC, cycle, ins, "")
        put_ins_into_rs(
            rs_fp_adder, index, ins, ROB, rat_int, rat_fp
        )
        update_rat(ROB, rat_int, rat_fp)
        PC.PC += 1
        return True

    # FP multiplication.
    if op == "mult.d":
        index = check_rs_space(rs_fp_multi)
        if index < 0:
            return False

        put_ins_into_ROB(ROB, size_ROB, PC, cycle, ins, "")
        put_ins_into_rs(
            rs_fp_multi, index, ins, ROB, rat_int, rat_fp
        )
        update_rat(ROB, rat_int, rat_fp)
        PC.PC += 1
        return True

    # Conditional branches use the integer reservation stations.
    if op in ("bne", "beq"):
        index = check_rs_space(rs_int_adder)
        if index < 0:
            return False

        branch_pc = PC.PC
        offset = int(tokens[-1])

        put_ins_into_ROB(ROB, size_ROB, PC, cycle, ins, "")
        put_bne_into_rs(
            rs_int_adder, index, ins, rat_int, rat_fp, ROB
        )

        # PC is an instruction index; see _branch_target for the offset units.
        actual_target_pc = _branch_target(branch_pc, offset, len(instructions))

        if BTB is None or branch_predictions is None:
            # Backward compatibility with the original starter signature.
            PC.valid = 0
            return True

        btb_entry = BTB[btb_index(branch_pc)]

        if btb_entry["valid"] and btb_entry["branch_pc"] == branch_pc:
            predicted_taken = bool(btb_entry["predicted_taken"])
            predicted_target_pc = btb_entry["target_pc"]
        else:
            predicted_taken = False
            predicted_target_pc = None

        predicted_next_pc = (
            predicted_target_pc if predicted_taken else branch_pc + 1
        )

        branch_predictions[ROB[-1].ROB_tag] = {
            "branch_pc": branch_pc,
            "predicted_taken": predicted_taken,
            "predicted_next_pc": predicted_next_pc,
            "actual_target_pc": actual_target_pc,
        }

        PC.PC = predicted_next_pc
        return True

    raise ValueError(f"Unsupported instruction at PC {PC.PC}: {ins}")


def issue(
    cycle, PC, instructions, ROB, size_ROB,
    rs_int_adder, rs_fp_adder, rs_fp_multi,
    ld_sd_queue, size_ld_sd_queue, rat_int, rat_fp,
    BTB=None, branch_predictions=None, issue_width=1
):
    """Issue up to issue_width instructions in program order."""
    if not isinstance(issue_width, int) or not 1 <= issue_width <= 4:
        raise ValueError("issue_width must be an integer from 1 to 4.")

    if not getattr(PC, "valid", 1):
        return

    issued = 0

    while issued < issue_width:
        if PC.PC < 0 or PC.PC >= len(instructions):
            PC.valid = 0
            break

        did_issue = _issue_one(
            cycle, PC, instructions, ROB, size_ROB,
            rs_int_adder, rs_fp_adder, rs_fp_multi,
            ld_sd_queue, size_ld_sd_queue, rat_int, rat_fp,
            BTB, branch_predictions
        )

        # Preserve in-order issue: never bypass a blocked instruction.
        if not did_issue:
            break

        issued += 1

        # Stop issuing after a branch without prediction support.
        if not PC.valid:
            break

    if PC.PC < 0 or PC.PC >= len(instructions):
        PC.valid = 0
