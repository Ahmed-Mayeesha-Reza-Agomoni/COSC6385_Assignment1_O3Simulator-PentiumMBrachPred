# Qing 
# 21st May 2017 

import sys
from copy import deepcopy
from collections import deque, namedtuple
from init import read_input, build_rs, ld_sd_entry, ld_sd_exe, ld_sd_mem, cdb, ROB_entry, PC, build_btb, btb_index
from print_status import ps, pss, print_table_header, print_final_state
from issue import issue, check_rs_space
import issue as issue_module            # only to set BRANCH_OFFSET_UNITS
from exe import exe 
from mem import mem
from wb import wb 
from commit import commit
import argparse
'''initialize'''
# CHANGED: everything now comes from ONE input file (assignment input format):
#   python main.py INPUT_FILE [--issue-width N]
# The issue width is the "Issue width = N" line of the file (default 1);
# --issue-width, if given, overrides it.
parser = argparse.ArgumentParser()
parser.add_argument('input', nargs='?', default='test_case.txt',
                    help='input file (config table, registers, memory, instructions)')
parser.add_argument('--issue-width', type=int, default=None,
                    choices=[1, 2, 3, 4])
args = parser.parse_args()
inp = read_input(args.input)
issue_width = args.issue_width if args.issue_width is not None else inp.issue_width
instructions = inp.instructions
issue_module.BRANCH_OFFSET_UNITS = inp.branch_offset

'''initialize regs, RAT, memory'''
reg_int = list(inp.reg_int)
rat_int = deepcopy(reg_int)

reg_fp = list(inp.reg_fp)
rat_fp = deepcopy(reg_fp)

memory = list(inp.memory)
'''intialize reservation stations'''
# 2 integer adder rs 
size_rs_int_adder = inp.config['int_adder'][0]
rs_int_adder = build_rs(size_rs_int_adder)
# 3 fp adder rs
size_rs_fp_adder = inp.config['fp_adder'][0]
rs_fp_adder = build_rs(size_rs_fp_adder)
# 2 fp multiplier rs
size_rs_fp_multi = inp.config['fp_multi'][0]
rs_fp_multi = build_rs(size_rs_fp_multi)
'''initilize function unit'''
# 1 cycle in int adder 
fu_int_adder = deque()
time_fu_int_adder = inp.config['int_adder'][1]
# 3 cycles in fp adder 
fu_fp_adder = deque()
time_fu_fp_adder = inp.config['fp_adder'][1]
# 20 cycles in fp multiplier
fu_fp_multi = deque()
time_fu_fp_multi = inp.config['fp_multi'][1]
'''initialize load/store queue'''
ld_sd_queue = deque()
size_ld_sd_queue = inp.config['ld_sd'][0]
ld_sd_exe = ld_sd_exe()
ld_sd_exe.busy = 0
time_ld_sd_exe = inp.config['ld_sd'][1]
ld_sd_mem = ld_sd_mem()
ld_sd_mem.busy = 0
time_ld_sd_mem = inp.config['ld_sd'][2]
'''initialize ROB'''
ROB = deque()
size_ROB = inp.rob_entries
'''initialize CDB'''
results_buffer = deque()
cdb = cdb()
cdb.valid = 0
"""issue first instruction"""
# instruction pointer 
PC = PC()
PC.PC = 0
PC.valid = 1 
BTB = build_btb()
branch_predictions = {}
cycle = 1
recovery_resume_cycle = None
pending_recovery = None

# print title
print_table_header()

# main
while (len(ROB) > 0 or cycle == 1 or recovery_resume_cycle is not None):
    if (recovery_resume_cycle is not None and cycle >= recovery_resume_cycle):
        PC.valid = 1
        recovery_resume_cycle = None
    
    '''ISSUE stage'''
    if (PC.PC<len(instructions))&(PC.valid==1):
        issue(cycle, PC, instructions, ROB, size_ROB, 
                rs_int_adder, 
                rs_fp_adder, 
                rs_fp_multi, 
                ld_sd_queue, size_ld_sd_queue, 
                rat_int, rat_fp,BTB, branch_predictions,issue_width=issue_width)

    '''EXE stage'''
    exe(fu_int_adder, time_fu_int_adder, 
        fu_fp_adder, time_fu_fp_adder, 
        fu_fp_multi, time_fu_fp_multi, results_buffer,  
        rs_int_adder, rs_fp_adder, rs_fp_multi, 
        ld_sd_exe, time_ld_sd_exe, ld_sd_queue,
        cycle, ROB, PC, BTB, branch_predictions)
        # Capture a branch misprediction detected by exe().
    
    if '_recovery_pending' in branch_predictions:
        pending_recovery = branch_predictions.pop('_recovery_pending')
        PC.PC = pending_recovery['recovery_pc']
        recovery_resume_cycle = pending_recovery['detected_cycle'] + 2

        # Find the mispredicted branch in the ROB.
        branch_tag = pending_recovery['branch_tag']
        rob_entries = list(ROB)
        branch_index = next(
            (i for i, entry in enumerate(rob_entries)
             if entry.ROB_tag == branch_tag),
            None
        )
        # NEW: a memory-order replay with nothing older than the load left
        # in the ROB has no surviving instruction (tag None).
        if branch_tag is None:
            branch_index = -1

        if branch_index is None:
            raise RuntimeError(
                'Mispredicted branch not found in ROB: ' + str(branch_tag)
            )

        # Keep the branch and all older instructions.
        ROB.clear()
        ROB.extend(rob_entries[:branch_index + 1])
        surviving_tags = {entry.ROB_tag for entry in ROB}

        # Remove prediction records for instructions discarded during recovery.
        for tag in list(branch_predictions):
            if tag != '_recovery_pending' and tag not in surviving_tags:
                del branch_predictions[tag]

        # Rebuild RAT from committed registers and surviving ROB entries.
        rat_int[:] = deepcopy(reg_int)
        rat_fp[:] = deepcopy(reg_fp)

        for entry in ROB:
            destination = entry.dest_tag

            if not isinstance(destination, str):
                continue

            if destination.startswith('R'):
                reg_index = int(destination[1:])
                if reg_index != 0:
                    rat_int[reg_index] = (
                        entry.value if entry.cdb else entry.ROB_tag
                    )

            elif destination.startswith('F'):
                reg_index = int(destination[1:])
                rat_fp[reg_index] = (
                    entry.value if entry.cdb else entry.ROB_tag
                )

        # Clear reservation stations belonging to discarded instructions.
        for rs in (rs_int_adder, rs_fp_adder, rs_fp_multi):
            for entry in rs:
                if entry.busy and entry.dest_tag not in surviving_tags:
                    entry.busy = 0
                    entry.op = None
                    entry.tag_1st = None
                    entry.value_1st = 0
                    entry.valid_1st = 0
                    entry.tag_2nd = None
                    entry.value_2nd = 0
                    entry.valid_2nd = 0
                    entry.dest_tag = None
                # Clear stale operand dependencies on discarded ROB tags.

        # Remove discarded instructions from functional-unit queues.
        fu_int_adder = deque(
            entry for entry in fu_int_adder
            if entry.dest_tag in surviving_tags
        )
        fu_fp_adder = deque(
            entry for entry in fu_fp_adder
            if entry.dest_tag in surviving_tags
        )
        fu_fp_multi = deque(
            entry for entry in fu_fp_multi
            if entry.dest_tag in surviving_tags
        )

        # Remove wrong-path load/store entries.
        ld_sd_queue = deque(
            entry for entry in ld_sd_queue
            if entry.dest_tag in surviving_tags
        )

        # Remove results from discarded instructions.
        results_buffer = deque(
            entry for entry in results_buffer
            if entry.dest_tag in surviving_tags
        )

        # Clear dedicated load/store execution if its instruction was discarded.
        # if (ld_sd_exe.busy and
        #         ld_sd_exe.dest_tag not in surviving_tags):
        if (ld_sd_exe.busy and not any(entry.ld_sd_tag == ld_sd_exe.dest_tag
                for entry in ld_sd_queue)):
            ld_sd_exe.busy = 0
            ld_sd_exe.cycle = 0
            ld_sd_exe.value1 = 0
            ld_sd_exe.value2 = 0
            ld_sd_exe.dest_tag = None

        if (ld_sd_mem.busy and
                ld_sd_mem.dest_tag not in surviving_tags):
            ld_sd_mem.busy = 0
            ld_sd_mem.cycle = 0
            ld_sd_mem.op = None
            ld_sd_mem.data = None
            ld_sd_mem.address = None
            ld_sd_mem.dest_tag = None


    '''MEM stage'''
    mem(ld_sd_queue, ld_sd_mem, time_ld_sd_mem, results_buffer,
        memory, ROB, cycle)

    '''CDB stage'''
    wb(cdb, rat_int, rat_fp, 
        rs_int_adder, rs_fp_adder, rs_fp_multi,
        ld_sd_queue, ROB, cycle,
        results_buffer) 
    
    '''COMMIT stage'''
    commit(ROB, reg_int, reg_fp, cycle, instructions,
       ld_sd_queue, memory)
    
    # cycle number 
    cycle +=1
    if cycle > 100000:                 # safety net against a deadlock
        sys.exit('ERROR: simulation did not finish after 100000 cycles')

# output in the handout format (the table rows were printed at commit)
print_final_state(reg_int, reg_fp, memory)
