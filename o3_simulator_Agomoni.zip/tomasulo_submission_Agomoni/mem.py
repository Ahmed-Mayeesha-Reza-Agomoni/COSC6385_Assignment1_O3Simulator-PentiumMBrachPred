# Qing 
# 26th May 2017

''' 
1. Ld forward check from Sd in ld_sd_queue
    -- only check nearest Sd instruction
2. execute LD/SD instruction in ld_sd_mem
    -- once LD instruction gets data, write back to ld_sd_queue
    -- LD instruction should be removed after get data  
    -- SD instruction should be removed at commit stage 
3. fetch new LD/SD instruction into ld_sd_mem
    -- if first element is SD, ready and has valid data, only SD to be committed can be fetched into ld_sd_mem 
    -- else put the first no-matched Ld into ld_sd_mem    
'''
from init import fu_result

# function: forward check from sd
# only check nearest sd
def forward_check_from_sd(ld_sd_queue, index):
    for i in reversed(range(index)):
        store = ld_sd_queue[i]

        # CHANGED: a store whose address is not calculated yet (ready == 0)
        # holds a meaningless address, so it is skipped (handout: "there are
        # still unresolved memory addresses for stores").
        if store.op == 'Sd' and store.ready == 1 and store.address == ld_sd_queue[index].address:
            if isinstance(store.data, (int, float)):
                return [store.data]
            return []

    return []

# function: check if previous all Sds are ready and un-matched
def check_all_previous_Sd_no_match(ld_sd_queue, index):
    flag = True
    for i in range(index):
        # all Sd instructions
        if (ld_sd_queue[i].op=='Sd'):
            # CHANGED (handout): a load may go to memory even if earlier
            # stores have unresolved addresses. If that turns out to be wrong,
            # check_memory_order() below detects it and the load is replayed.
            if ld_sd_queue[i].ready == 0:
                pass
            elif (ld_sd_queue[i].address==ld_sd_queue[index].address):
                flag = False
                break
            else:
                pass
    return flag
 
# function: find ROB entry by tag
def find_ROB_entry(ROB, tag):
    for index, entry in enumerate(ROB):
        if entry.ROB_tag == tag:
            return index
    return -1

# function: put entry into ld_sd_mem
def put_entry_into_ld_sd_mem(ld_sd_mem, entry):
    ld_sd_mem.busy = 1
    ld_sd_mem.cycle = 0
    ld_sd_mem.address = entry.address
    ld_sd_mem.dest_tag = entry.dest_tag
    ld_sd_mem.op = entry.op
    if ld_sd_mem.op == 'Sd':
        ld_sd_mem.data = entry.data

# function: check if Sd to be committed in next cycle 
# def check_if_sd_committable(ld_sd_queue, ROB):
#     flag = False
#     if ld_sd_queue[0].ldsd_tag == ROB[0].dest_tag:
#         flag = True
#     if ld_sd_queue[0].ldsd_tag == ROB[1].dest_tag:
#         # previous ins has been broadcasted
#         if len(ROB[0].cdb)!=0:
#             flag = True
#     return flag

def check_if_sd_committable(ld_sd_queue, ROB):
    if not ld_sd_queue or not ROB:
        return False

    store_tag = ld_sd_queue[0].dest_tag

    # The store must be at the ROB head to commit next.
    return ROB[0].ROB_tag == store_tag


# ---------------------------------------------------------------------------
# NEW (assignment: load/store queue). Memory order check.
# A load may get its data before an OLDER store's address is known. If that
# store's address later turns out to be the load's address, the load has the
# wrong value. load_records remembers every load that got data and is not
# committed yet: [ROB entry of the load, address, ROB entry of the store it
# forwarded from (None = it read memory)]. Entries are ROB objects, not tags,
# because ROB tags are reused.
# ---------------------------------------------------------------------------
load_records = []
checked_stores = []      # ROB entries of stores whose address was already checked


def index_of_source(ld_sd_queue, index):
    """Queue index of the store the load at 'index' forwards from."""
    for i in reversed(range(index)):
        s = ld_sd_queue[i]
        if s.op == 'Sd' and s.ready == 1 and s.address == ld_sd_queue[index].address:
            return i
    return -1


def record_load(ROB, load, source_store):
    pos = find_ROB_entry(ROB, load.dest_tag)
    if pos == -1:
        return
    source = None
    if source_store is not None:
        spos = find_ROB_entry(ROB, source_store.dest_tag)
        source = ROB[spos] if spos != -1 else None
    load_records.append([ROB[pos], load.address, source])


def check_memory_order(ld_sd_queue, ROB):
    """Called every cycle after the store addresses were calculated.
    Returns None, or a dict describing the replay of the OLDEST wrong load:
    {'keep_tag': tag of the last instruction that survives (None = nothing),
     'keep_pos': its position in the ROB (-1 = nothing),
     'restart_pc': instruction index of the load}"""
    rob_list = list(ROB)

    def pos(entry):
        for i, e in enumerate(rob_list):
            if e is entry:
                return i
        return -1

    # forget loads that left the ROB (committed or squashed) and old stores
    load_records[:] = [r for r in load_records if pos(r[0]) != -1]
    checked_stores[:] = [s for s in checked_stores if pos(s) != -1]

    worst = None
    for store in ld_sd_queue:
        if store.op != 'Sd' or store.ready != 1:
            continue
        spos = find_ROB_entry(ROB, store.dest_tag)
        if spos == -1:
            continue
        rob_store = ROB[spos]
        if any(s is rob_store for s in checked_stores):
            continue
        checked_stores.append(rob_store)
        for rec in load_records:
            lpos = pos(rec[0])
            if lpos <= spos or rec[1] != store.address:
                continue                     # the load is older, or another address
            source_pos = pos(rec[2]) if rec[2] is not None else -1
            if source_pos > spos:
                continue                     # it got the data from a NEARER store
            if worst is None or lpos < worst:
                worst = lpos
    if worst is None:
        return None
    return {'keep_tag': ROB[worst - 1].ROB_tag if worst > 0 else None,
            'keep_pos': worst - 1,
            'restart_pc': rob_list[worst].PC}


# function: mem 
def mem(ld_sd_queue, ld_sd_mem, time_ld_sd_mem, results_buffer, 
        memory, ROB, cycle):
    '''look forward check for all Ld instructions'''
    index = -1
    remove_list = []
    for element in ld_sd_queue:
        index += 1
        if (index>=1)&(element.op=='Ld')&(element.ready==1):
            data = forward_check_from_sd(ld_sd_queue, index)
            if len(data)>0:
                # Ld gets data 
                results_buffer.append(fu_result())
                results_buffer[-1].value = data[0]
                results_buffer[-1].dest_tag = element.dest_tag
                # remove the Ld instruction
                remove_list.append(element)
                # remember where this load's data came from (memory order check)
                record_load(ROB, element, ld_sd_queue[index_of_source(ld_sd_queue, index)])
                # write mem cylce in ROB
                rob_index = find_ROB_entry(ROB, element.dest_tag)
                if rob_index == -1:
                    raise RuntimeError(
                        f"Forwarded load ROB tag not found: {element.dest_tag}"
                    )
                ROB[rob_index].mem.append(cycle)
    # remove lookforwared Ld
    for element in remove_list:
        ld_sd_queue.remove(element)
    '''ld_sd_mem execution'''
    if ld_sd_mem.busy == 1:
        # write mem starting cycle 
        if ld_sd_mem.cycle == 0:
            rob_index = find_ROB_entry(ROB, ld_sd_mem.dest_tag)
            if rob_index == -1:
                raise RuntimeError(
                    f"Memory operation ROB tag not found: {ld_sd_mem.dest_tag}"
                )
            ROB[rob_index].mem.extend([cycle, cycle + time_ld_sd_mem - 1])
            # for Sd, write commit cycle
            # if ld_sd_mem.op == 'Sd':
            #     ROB[rob_index].commit.append(cycle)
        
        # cycle ++
        ld_sd_mem.cycle +=1
        # get the data for Ld or reach the memory for Sd
        if ld_sd_mem.cycle == time_ld_sd_mem:
            ld_sd_mem.busy = 0
            if ld_sd_mem.op == 'Ld': 
                # put Ld data into results_buffer
                address = ld_sd_mem.address 
                data = memory[address]
                results_buffer.append(fu_result())
                results_buffer[-1].value = data
                results_buffer[-1].dest_tag = ld_sd_mem.dest_tag
            # put data into memory for Sd
            else:
                #memory[ld_sd_mem.address]=ld_sd_mem.data
                #pass
                return

    '''fetch new instruction into ld_sd_mem'''
    if (ld_sd_mem.busy==0)&(len(ld_sd_queue)>0):
        # flag_1st_ldsd
        flag_1st_ldsd_sent = False 
        # fetch the ld_sd_queue header if it's Sd, ready and to be committed
        if (ld_sd_queue[0].op=='Sd'):
            # check if this Sd is ready and to be commited 
            if (ld_sd_queue[0].ready==1):
                # check to be committed in next cycle
                if check_if_sd_committable(ld_sd_queue, ROB):
                    # already have data in Sd
                    if (type(ld_sd_queue[0].data)==int)|(type(ld_sd_queue[0].data)==float):
                        # put the Sd entry into ld_sd_mem
                        entry = ld_sd_queue[0]
                        put_entry_into_ld_sd_mem(ld_sd_mem, entry)
                        flag_1st_ldsd_sent = True
                        ld_sd_mem.busy = 1

        # if the 1st Sd is not sent to ld_sd_mem, or the 1st is not Sd
        if (flag_1st_ldsd_sent==False):
            for index in range(len(ld_sd_queue)):
                # ready Ld
                if (ld_sd_queue[index].op=='Ld')&(ld_sd_queue[index].ready==1):
                    # haven't got data
                    # CHANGED: was ld_sd_queue[0] (the queue HEAD), so a store
                    # waiting to commit at the head blocked every later load.
                    if (type(ld_sd_queue[index].data)!=int)&(type(ld_sd_queue[index].data)!=float):
                        # all previous Sd instructions are ready but no address match 
                        if check_all_previous_Sd_no_match(ld_sd_queue, index): 
                            put_entry_into_ld_sd_mem(ld_sd_mem, ld_sd_queue[index])
                            record_load(ROB, ld_sd_queue[index], None)
                            ld_sd_queue.remove(ld_sd_queue[index])
                            ld_sd_mem.busy =1
                            break 

