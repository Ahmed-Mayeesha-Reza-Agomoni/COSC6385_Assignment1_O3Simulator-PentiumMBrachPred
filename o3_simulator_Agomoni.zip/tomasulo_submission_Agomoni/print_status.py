# Qing 
# 21st May 2017

# function: print RS/ROB status
def ps(unit):
    if(len(unit)==0):
        print('empty!')
    else:
        # get all fields in namedtuple
        fields_list = unit[0]._fields
        for unit_item in unit:
            print ('******')
            for field in fields_list:
                print(field+': ', str(getattr(unit_item, field)))

# function: print single namedtuple
def pss(snt):
    fields_list = snt._fields
    for field in fields_list:
        print (field+': ', str(getattr(snt, field)))


# ---------------------------------------------------------------------------
# NEW (assignment: output format)
# The handout wants, after the instruction table, the REGISTER VALUES
# (R0..R31, F0..F31 with a "value:" line below each) and the NON-ZERO MEMORY
# VALUES (Addresses / Values). The instruction table itself is still printed
# row by row by commit.print_ROB(), as before.
# ---------------------------------------------------------------------------
def print_table_header():
    item = ''.ljust(30)
    for title in ('ISSUE', 'EX', 'MEM', 'WB', 'COMMIT'):
        item += title.ljust(15)
    print(item.rstrip())


def print_final_state(reg_int, reg_fp, memory):
    print()
    print('REGISTER VALUES')
    for prefix, regs in (('R', reg_int), ('F', reg_fp)):
        names = ''.ljust(7)
        values = 'value:'.ljust(7)
        for i in range(len(regs)):
            name = '%s%d' % (prefix, i)
            text = repr(regs[i])
            # normally 9 characters wide; wider for long numbers such as
            # 0.15000000000000002 so that two values never run together
            width = max(9, len(text) + 1)
            names += name.ljust(width)
            values += text.ljust(width)
        print(names.rstrip())
        print(values.rstrip())
    print()
    print('NON-ZERO MEMORY VALUES')
    print('Addresses'.ljust(12) + 'Values')
    for address in range(len(memory)):
        if memory[address] != 0:
            print(str(address).ljust(12) + repr(memory[address]))
