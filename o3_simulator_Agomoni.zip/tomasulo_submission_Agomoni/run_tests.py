# run_tests.py -- runs every tests/*.txt at issue widths 1-4 and checks the final
# registers and memory against a simple one-instruction-at-a-time interpreter.
# usage: python run_tests.py            (prints one line per test and a cycle table)
import glob, os, re, subprocess, sys
from init import read_input
import issue


def reference(inp, max_steps=100000):
    """Execute the program in order, one instruction at a time (no pipeline)."""
    issue.BRANCH_OFFSET_UNITS = inp.branch_offset
    R, F, M = list(inp.reg_int), list(inp.reg_fp), list(inp.memory)
    prog = inp.instructions
    pc, steps = 0, 0
    while pc < len(prog) and steps < max_steps:
        steps += 1
        t = prog[pc].replace(',', ' ').split()
        op = t[0]
        nxt = pc + 1
        r = lambda s: int(s[1:])
        if op == 'Ld':
            m = re.match(r'(-?\d+)\(R(\d+)\)', t[2])
            F[r(t[1])] = M[R[int(m[2])] + int(m[1])]
        elif op == 'Sd':
            m = re.match(r'(-?\d+)\(R(\d+)\)', t[2])
            M[R[int(m[2])] + int(m[1])] = F[r(t[1])]
        elif op == 'Add': R[r(t[1])] = R[r(t[2])] + R[r(t[3])]
        elif op == 'Sub': R[r(t[1])] = R[r(t[2])] - R[r(t[3])]
        elif op == 'Addi': R[r(t[1])] = R[r(t[2])] + int(t[3])
        elif op == 'Add.d': F[r(t[1])] = F[r(t[2])] + F[r(t[3])]
        elif op == 'Sub.d': F[r(t[1])] = F[r(t[2])] - F[r(t[3])]
        elif op == 'Mult.d': F[r(t[1])] = F[r(t[2])] * F[r(t[3])]
        else:
            a, b = R[r(t[1])], R[r(t[2])]
            if (op == 'Bne' and a != b) or (op == 'Beq' and a == b):
                nxt = issue._branch_target(pc, int(t[3]), len(prog))
        R[0] = 0
        pc = nxt
    if steps >= max_steps:
        return None
    return ({i: v for i, v in enumerate(R) if v}, {i: v for i, v in enumerate(F) if v},
            {i: v for i, v in enumerate(M) if v})


def run_sim(path, width):
    p = subprocess.run([sys.executable, 'main.py', path, '--issue-width', str(width)],
                       capture_output=True, text=True, timeout=120)
    if p.returncode != 0:
        return None, p.stderr.strip().splitlines()[-1]
    lines = p.stdout.splitlines()
    k = lines.index('REGISTER VALUES')
    R, F, M = {}, {}, {}
    for names, vals, dst, cast in ((k + 1, k + 2, R, int), (k + 3, k + 4, F, float)):
        for n, v in zip(lines[names].split(), lines[vals].split()[1:]):
            if float(v) != 0:
                dst[int(n[1:])] = cast(float(v)) if cast is int else float(v)
    for l in lines[lines.index('NON-ZERO MEMORY VALUES') + 2:]:
        a, v = l.split()
        if float(v) != 0:
            M[int(a)] = float(v)
    last = [l for l in lines[:k] if l.strip().endswith(']')][-1]
    cycles = int(re.findall(r'\d+', last.split('[')[-1])[-1])
    return (R, F, M, cycles), None


def main():
    files = sorted(glob.glob('tests/*.txt'))
    table, bad = [], 0
    for path in files:
        inp = read_input(path)
        want = reference(inp)
        row = [os.path.basename(path)[:-4]]
        for w in (1, 2, 3, 4):
            got, err = run_sim(path, w)
            if got is None:
                row.append('ERROR'); bad += 1; print('FAIL', path, w, err)
            elif want is None:
                row.append('?')
            elif got[:3] != want:
                row.append('WRONG'); bad += 1; print('FAIL', path, w, 'final state differs')
            else:
                row.append(str(got[3]))
        table.append(row)
    print()
    print('%-18s %8s %8s %8s %8s   (cycles until the last commit)' % ('test', 'width 1', 'width 2', 'width 3', 'width 4'))
    for row in table:
        print('%-18s %8s %8s %8s %8s' % tuple(row))
    print('\n%d failures' % bad)
    return bad


if __name__ == '__main__':
    sys.exit(1 if main() else 0)
