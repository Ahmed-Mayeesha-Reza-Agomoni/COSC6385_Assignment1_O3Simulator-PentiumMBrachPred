# Qing 
# 29th may 2017
'''
1. commit ROB_buffer
2. fetch header into ROB_buffer
'''

# function: print ROB entry 
def print_ROB(entry, instructions):
    item = instructions[entry.PC].ljust(30)
    item += str(entry.issue).ljust(15) 
    item += str(entry.exe).ljust(15) 
    item += str(entry.mem).ljust(15)
    item += str(entry.cdb).ljust(15)
    item += str(entry.commit)
    print(item)
# function: modify architectual reg
def modify_arch_reg(entry, reg_int, reg_fp):
    if entry.dest_tag[0] == 'F':
        reg_fp[int(entry.dest_tag[1:])] = entry.value
    elif entry.dest_tag[0] == 'R':
        reg_int[int(entry.dest_tag[1:])] = entry.value
    else:
        pass

# function: commit

def commit(ROB, reg_int, reg_fp, cycle, instructions,
           ld_sd_queue, memory):
    if not ROB:
        return

    op = instructions[ROB[0].PC].split()[0].lower()
    entry = ROB[0]

    if op in ('bne', 'beq'):
        if entry.exe:
            entry.commit.append(cycle + 1)
            entry = ROB.popleft()
            print_ROB(entry, instructions)
        return

    # A store commits only when it reaches the ROB head and
    # its address, data, and memory operation are ready.
    if op == 'sd':
        if len(entry.mem) < 2 or cycle < entry.mem[-1]:
            return

        store = next(
            (item for item in ld_sd_queue
             if item.dest_tag == entry.ROB_tag),
            None
        )
        if store is None or store.ready != 1:
            return
        if not isinstance(store.data, (int, float)):
            return

        memory[store.address] = store.data
        ld_sd_queue.remove(store)
        entry.commit.append(cycle + 1)
        entry = ROB.popleft()
        print_ROB(entry, instructions)
        return

    if entry.cdb:
        entry.commit.append(cycle + 1)
        entry = ROB.popleft()
        modify_arch_reg(entry, reg_int, reg_fp)
        print_ROB(entry, instructions)
