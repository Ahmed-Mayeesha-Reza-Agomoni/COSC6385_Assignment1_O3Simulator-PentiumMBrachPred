# Qing 
# 24th May 2017

''' 
1. calculate valid instructions
    -- for ALU instructions, write results into fu_results, remove that fu entry  
    -- for LD/SD, write address result immediately back to ld_sd_queue
2. fetch instructions into function unit with spare space
    -- remove ALU instructions from rs
    -- don't remove ld/sd instructions
'''
#from init import fu_entry, fu_result
from init import fu_entry, fu_result, btb_index
# function: check rs and return valid instruction index
def check_valid_ins_in_rs(rs):
    index = -1
    if len(rs)!=0:
        for i in range(len(rs)):
            if (rs[i].valid_1st==1)&(rs[i].valid_2nd==1)&(rs[i].busy==1):
                index = i
                break
    return index

# function: check ld_sd_queue and return valid instruction index
def check_valid_ins_in_ldsd(ldsd):
    index = -1
    if len(ldsd)!=0:
        for i in range(len(ldsd)):
            if (ldsd[i].valid==1) & (ldsd[i].ready==0):
                index = i
                break
    return index

# function: add entry into fu 
def add_entry_into_fu(fu, ins_in_rs):
    fu[-1].cycle = 0
    fu[-1].op = ins_in_rs.op
    fu[-1].value1 = ins_in_rs.value_1st
    fu[-1].value2 = ins_in_rs.value_2nd
    fu[-1].dest_tag = ins_in_rs.dest_tag

# function: find ROB entry by tag

def find_ROB_entry(ROB, tag):
    for index, entry in enumerate(ROB):
        if entry.ROB_tag == tag:
            return index
    raise RuntimeError(f"ROB tag not found: {tag}")


# function: functional units execution 
def fu_exe(fu, fu_results, ROB, time_fu, cycle, PC,BTB, branch_predictions):
    if len(fu)!=0:
    #     print("DEBUG FU:", [
    #     (e.dest_tag, e.op, e.cycle, e.value1, e.value2)
    #     for e in fu
    # ])
        for element in fu:
            element.cycle += 1
        # write starting cycle 
        if fu[-1].cycle == 1:
            index = find_ROB_entry(ROB, fu[-1].dest_tag)
            ROB[index].exe.append(cycle)
        # finish cycle
        if fu[0].op in ('Bne', 'Beq'):
            print("DEBUG branch:", fu[0].dest_tag,
                "operands:", fu[0].value1, fu[0].value2)
        if fu[0].cycle == time_fu:
            index = find_ROB_entry(ROB, fu[0].dest_tag)
            ROB[index].exe.append(cycle)
            # calculation result
            fu_results.append(fu_result())
            fu_results[-1].dest_tag = fu[0].dest_tag
            if (fu[0].op=='Add')|(fu[0].op=='Add.d')|(fu[0].op=='Addi'):
                fu_results[-1].value = fu[0].value1 + fu[0].value2
            elif (fu[0].op=='Sub')|(fu[0].op=='Sub.d'):
                fu_results[-1].value = fu[0].value1 - fu[0].value2
            elif (fu[0].op=='Mult.d'):
                fu_results[-1].value = fu[0].value1 * fu[0].value2
            # elif (fu[0].op=='Bne'):
            #     fu_results.pop()
            #     if fu[0].value1 == fu[0].value2:
            #         PC.PC += 1
            #         PC.valid = 1
            #     else:
            #         index = find_ROB_entry(ROB, fu[0].dest_tag)
            #         offset = ROB[index].dest_tag
            #         PC.PC = int(PC.PC + 1 + offset/4)
            #         PC.valid = 1
            elif fu[0].op in ('Bne', 'Beq'):
                fu_results.pop()

                branch_tag = fu[0].dest_tag
                rob_index = find_ROB_entry(ROB, branch_tag)
                prediction = branch_predictions[branch_tag]

                value1 = fu[0].value1
                value2 = fu[0].value2

                if fu[0].op == 'Bne':
                    actual_taken = value1 != value2
                else:
                    actual_taken = value1 == value2

                branch_pc = prediction['branch_pc']
                actual_target_pc = prediction['actual_target_pc']

                if actual_taken:
                    actual_next_pc = actual_target_pc
                else:
                    actual_next_pc = branch_pc + 1

                # Update BTB with the resolved branch outcome.
                btb_entry = BTB[btb_index(branch_pc)]
                btb_entry['valid'] = True
                btb_entry['branch_pc'] = branch_pc
                btb_entry['target_pc'] = actual_target_pc
                btb_entry['predicted_taken'] = actual_taken

                # Detect a misprediction.
                print(
                f"BRANCH RESOLVE: tag={branch_tag}, PC={branch_pc}, "
                f"op={fu[0].op}, taken={actual_taken}, "
                f"predicted_next={prediction['predicted_next_pc']}, "
                f"actual_next={actual_next_pc}"
            )
                if actual_next_pc != prediction['predicted_next_pc']:
                    print(f"MISPREDICTION: recovering to PC {actual_next_pc}")
                    PC.PC = actual_next_pc
                    PC.valid = 0
                    branch_predictions['_recovery_pending'] = {
                        'branch_tag': branch_tag,
                        'branch_pc': branch_pc,
                        'recovery_pc': actual_next_pc,
                        'detected_cycle': cycle
                    }
                # if actual_next_pc != prediction['predicted_next_pc']:
                #     PC.PC = actual_next_pc
                #     PC.valid = 0
                #     branch_predictions['_recovery_pending'] = True

                # Remove the resolved branch's prediction record.
                branch_predictions.pop(branch_tag, None)
            else:
                pass
            # remove from fu 
            fu.popleft()

# function: ld_sd_execution 
def ld_sd_execution(ld_sd_exe, time_ld_sd_exe, ld_sd_queue, ROB, cycle):
    if ld_sd_exe.busy == 1:
        # write down starting cycle
        if ld_sd_exe.cycle == 0:            
            for element in ld_sd_queue:
                if element.ld_sd_tag == ld_sd_exe.dest_tag:
                    break
            index = find_ROB_entry(ROB, element.dest_tag)
            ROB[index].exe.append(cycle)
            # execute 
            ld_sd_exe.cycle += 1
        # write address back to ld_sd_queue
        if ld_sd_exe.cycle == time_ld_sd_exe:
            address = ld_sd_exe.value1 + ld_sd_exe.value2
            for element in ld_sd_queue:
                if element.ld_sd_tag == ld_sd_exe.dest_tag:
                    element.address = address
                    element.ready = 1
                    break
            # write down finish cycle
            index = find_ROB_entry(ROB, element.dest_tag)
            ROB[index].exe.append(cycle)
            ld_sd_exe.busy = 0

# function: execution
# def exe(fu_int_adder, time_fu_int_adder,
#         fu_fp_adder, time_fu_fp_adder,
#         fu_fp_multi, time_fu_fp_multi, results_buffer,
#         rs_int_adder, rs_fp_adder, rs_fp_multi, 
#         ld_sd_exe, time_ld_sd_exe, ld_sd_queue,
#         cycle, ROB, PC):
def exe(fu_int_adder, time_fu_int_adder,
        fu_fp_adder, time_fu_fp_adder,
        fu_fp_multi, time_fu_fp_multi, results_buffer,
        rs_int_adder, rs_fp_adder, rs_fp_multi,
        ld_sd_exe, time_ld_sd_exe, ld_sd_queue,
        cycle, ROB, PC, BTB, branch_predictions):

    '''execution in fu and ld_sd address calculation'''
    
    ld_sd_execution(ld_sd_exe, time_ld_sd_exe, ld_sd_queue, ROB, cycle) 
    # functional units 
    fu_exe(fu_int_adder, results_buffer, ROB, time_fu_int_adder, cycle, PC, BTB, branch_predictions)
    fu_exe(fu_fp_adder, results_buffer, ROB, time_fu_fp_adder, cycle, PC, BTB, branch_predictions)
    fu_exe(fu_fp_multi, results_buffer, ROB, time_fu_fp_multi, cycle, PC, BTB, branch_predictions)
    '''fetch instructions from rs and ld_sd_queue'''
    # from ld_sd_queue
    # check valid ins in ld_sd_queue 
    index = check_valid_ins_in_ldsd(ld_sd_queue)
    # put ins into ld_sd_exe
    if (index>=0)&(ld_sd_exe.busy==0):
        ld_sd_exe.busy = 1
        ld_sd_exe.cycle = 0
        ld_sd_exe.value1 = ld_sd_queue[index].reg_value
        ld_sd_exe.value2 = ld_sd_queue[index].immediate
        ld_sd_exe.dest_tag = ld_sd_queue[index].ld_sd_tag
        if ROB[find_ROB_entry(ROB, ld_sd_queue[index].dest_tag)].issue[0] < cycle:
            ld_sd_execution(ld_sd_exe, time_ld_sd_exe, ld_sd_queue, ROB, cycle)
    # from rs 
    # int_adder
    # fetch valid instruction 
    if check_valid_ins_in_rs(rs_int_adder)>=0:
        index = check_valid_ins_in_rs(rs_int_adder)
        fu_int_adder.append(fu_entry())
        add_entry_into_fu(fu_int_adder, rs_int_adder[index])
        rs_int_adder[index].busy = 0
    # fp_adder
    if check_valid_ins_in_rs(rs_fp_adder)>=0:
        index = check_valid_ins_in_rs(rs_fp_adder)
        fu_fp_adder.append(fu_entry())
        add_entry_into_fu(fu_fp_adder, rs_fp_adder[index])
        rs_fp_adder[index].busy = 0
    # fp_multi
    if check_valid_ins_in_rs(rs_fp_multi)>=0:
        index = check_valid_ins_in_rs(rs_fp_multi)
        fu_fp_multi.append(fu_entry())
        add_entry_into_fu(fu_fp_multi, rs_fp_multi[index])
        rs_fp_multi[index].busy = 0

