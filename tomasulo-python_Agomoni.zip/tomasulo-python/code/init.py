# Qing 
# 21st May 2017 

# from collections import namedtuple

# '''define data types'''
# # reservation station 
# def rs_entry():
#     rs_entry = namedtuple('rs_entry', 'busy, op, tag_1st, value_1st, valid_1st, tag_2nd, value_2nd, valid_2nd, dest_tag')
#     temp = rs_entry
#     return temp 
# # functional unit 
# def fu_entry():
#     fu_entry = namedtuple('fu_entry', 'cycle, op, value1, value2, dest_tag')
#     temp = fu_entry
#     return temp
# # function result 
# def fu_result():
#     fu_result = namedtuple('fu_result', 'value, dest_tag')
#     temp = fu_result
#     return temp
# # ld/sd entry
# def ld_sd_entry():
#     ld_sd_entry = namedtuple('ld_sd_entry', 'ld_sd_tag, ready, op, address, data, dest_tag, immediate, reg_tag, reg_value, valid')
#     temp = ld_sd_entry
#     return temp
# # ld/sd exe
# def ld_sd_exe():
#     ld_sd_exe = namedtuple('ld_sd_exe', 'busy, cycle, value1, value2, dest_tag')
#     temp = ld_sd_exe
#     return temp
# # ld/sd mem
# def ld_sd_mem():
#     ld_sd_mem = namedtuple('ld_sd_mem', 'busy, cycle, op, data, address, dest_tag')
#     temp = ld_sd_mem
#     return temp
# # cdb
# def cdb():
#     cdb = namedtuple('cdb', 'valid, value, dest_tag')
#     temp = cdb
#     return temp
# # ROB_entry 
# def ROB_entry():
#     ROB_entry = namedtuple('ROB_entry', 'ROB_tag, PC, value, dest_tag, issue, exe, mem, cdb, commit')
#     temp = ROB_entry
#     temp.issue = []
#     temp.exe = []
#     temp.mem = []
#     temp.cdb = []
#     temp.commit =[]
#     return temp
# # PC 
# def PC():
#     PC = namedtuple('PC', 'PC, valid')
#     temp = PC
#     return temp


# Reservation station
class rs_entry:
    def __init__(self):
        self.busy = 0
        self.op = ''
        self.tag_1st = None
        self.value_1st = 0
        self.valid_1st = 0
        self.tag_2nd = None
        self.value_2nd = 0
        self.valid_2nd = 0
        self.dest_tag = None

# Functional unit
class fu_entry:
    def __init__(self):
        self.cycle = 0
        self.op = ''
        self.value1 = 0
        self.value2 = 0
        self.dest_tag = None

# Function result
class fu_result:
    def __init__(self):
        self.value = 0
        self.dest_tag = None

# Load/store entry
class ld_sd_entry:
    def __init__(self):
        self.ld_sd_tag = None
        self.ready = 0
        self.op = ''
        self.address = 0
        self.data = 0
        self.dest_tag = None
        self.immediate = 0
        self.reg_tag = None
        self.reg_value = 0
        self.valid = 0

# Load/store execution unit
class ld_sd_exe:
    def __init__(self):
        self.busy = 0
        self.cycle = 0
        self.value1 = 0
        self.value2 = 0
        self.dest_tag = None

# Load/store memory unit
class ld_sd_mem:
    def __init__(self):
        self.busy = 0
        self.cycle = 0
        self.op = ''
        self.data = 0
        self.address = 0
        self.dest_tag = None

# CDB
class cdb:
    def __init__(self):
        self.valid = 0
        self.value = 0
        self.dest_tag = None

# Reorder buffer entry
class ROB_entry:
    def __init__(self):
        self.ROB_tag = None
        self.PC = None
        self.value = 0
        self.dest_tag = None
        self.issue = []
        self.exe = []
        self.mem = []
        self.cdb = []
        self.commit = []

# Program counter
class PC:
    def __init__(self):
        self.PC = 0
        self.valid = 1

# function: read instructions
def read_instruction(codefile):
    with open(codefile) as f:
            instructions = f.read().splitlines()
    return instructions
# function: build rs
def build_rs(num):
    rs = []
    for _ in range(num):
        temp = rs_entry()
        temp.busy = 0
        rs.extend([temp])
    return rs


#Branch Target Buffer (BTB)
#8 entries, with a 1-bit direction predictor.
BTB_SIZE = 8


def build_btb():
    btb = []
    for _ in range(BTB_SIZE):
        btb.append({
            'valid': False,
            'branch_pc': None,
            'target_pc': None,
            'predicted_taken': False
        })
    return btb


def btb_index(pc):
    return pc & (BTB_SIZE - 1)

