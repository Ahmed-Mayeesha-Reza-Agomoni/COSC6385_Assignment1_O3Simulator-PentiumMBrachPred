# Qing 
# 21st May 2017 

from copy import deepcopy
from collections import deque, namedtuple
#from init import read_instruction, build_rs, ld_sd_entry, ld_sd_exe, ld_sd_mem, cdb, ROB_entry, PC
from init import read_instruction, build_rs, ld_sd_entry, ld_sd_exe, ld_sd_mem, cdb, ROB_entry, PC, build_btb, btb_index
from print_status import ps, pss
from issue import issue, check_rs_space
from exe import exe 
from mem import mem
from wb import wb 
from commit import commit
import argparse
'''initialize'''
# read instructions into a list 
parser = argparse.ArgumentParser()
parser.add_argument('--issue-width', type=int, default=1,
                    choices=[1, 2, 3, 4])
args = parser.parse_args()
issue_width = args.issue_width
instructions = read_instruction('code.in')
'''initialize regs, RAT, memory''' 
# # integer REG
# reg_int = []
# for i in range(32):
#     reg_int.extend([0])
# reg_int[1] = 12
# reg_int[2] = 32
# rat_int = deepcopy(reg_int)
# # fp REG
# reg_fp = []
# for i in range(32):
#     reg_fp.extend([0])
# reg_fp[20] = 3.0
# rat_fp = deepcopy(reg_fp)
# # memory 
# memory = []
# for i in range(256):
#     memory.extend([0])
# memory[4] = 3.0
# memory[8] = 2.0
# memory[12] = 1.0
# memory[24] = 6.0
# memory[28] = 5.0
# memory[32] = 4.0
'''initialize regs, RAT, memory'''

# # Integer registers
# reg_int = [0] * 32
# reg_int[1] = 12   # R1
# reg_int[2] = 12   # R2
# reg_int[3] = 0    # R3
# rat_int = deepcopy(reg_int)

# # Floating-point registers
# reg_fp = [0.0] * 32
# reg_fp[1] = 1.0  # F1
# reg_fp[2] = 2.0   # F2
# reg_fp[3] = 3.0
# reg_fp[7] = 100.0 # Sentinel: should remain unchanged
# rat_fp = deepcopy(reg_fp)

# # Memory
# memory = [0.0] * 256
# memory[8] = 5.0
# memory[12] = 7.0
# memory[16] = 9.0
# reg_int = [0] * 32
# reg_int[1] = 12
# reg_int[2] = 8
# reg_int[3] = 0
# rat_int = deepcopy(reg_int)

# reg_fp = [0.0] * 32
# reg_fp[1] = 2.0
# reg_fp[2] = 3.0
# rat_fp = deepcopy(reg_fp)

# memory = [0.0] * 256
# memory[8] = 5.0
# memory[12] = 7.0
# memory[16] = 9.0
# reg_int = [0] * 32
# reg_int[1] = 3
# reg_int[2] = 0
# rat_int = deepcopy(reg_int)

# reg_fp = [0.0] * 32
# rat_fp = deepcopy(reg_fp)

# memory = [0.0] * 256
# reg_int = [0] * 32
# rat_int = deepcopy(reg_int)

# reg_fp = [0.0] * 32
# rat_fp = deepcopy(reg_fp)

# memory = [0.0] * 256
# Integer registers
# reg_int = [0] * 32
# rat_int = deepcopy(reg_int)

# # Floating-point registers
# reg_fp = [0.0] * 32
# reg_fp[1] = 1.0  # F1
# reg_fp[2] = 2.0  # F2
# reg_fp[3] = 3.0  # F3
# reg_fp[4] = 1.0  # F4
# reg_fp[5] = 1.0  # F5
# reg_fp[6] = 1.0  # F6
# reg_fp[7] = 1.0  # F7
# reg_fp[8] = 1.0  # F8
# reg_fp[9] = 1.0  # F9
# rat_fp = deepcopy(reg_fp)

# # Memory (unused in this test)
# memory = [0.0] * 256
# reg_int = [0] * 32
# reg_int[1] = 0
# reg_int[2] = 0
# reg_int[3] = 0
# rat_int = deepcopy(reg_int)

# reg_fp = [0.0] * 32
# reg_fp[1] = 1.0  # F1
# reg_fp[2] = 2.0  # F2
# reg_fp[3] = 3.0  # F3
# rat_fp = deepcopy(reg_fp)

# memory = [0.0] * 256
reg_int = [0] * 32
rat_int = deepcopy(reg_int)

reg_fp = [0.0] * 32
rat_fp = deepcopy(reg_fp)

memory = [0.0] * 256
'''intialize reservation stations'''
# 2 integer adder rs 
size_rs_int_adder = 4 
rs_int_adder = build_rs(size_rs_int_adder)
# 3 fp adder rs
size_rs_fp_adder = 3
rs_fp_adder = build_rs(size_rs_fp_adder)
# 2 fp multiplier rs
size_rs_fp_multi = 2
rs_fp_multi = build_rs(size_rs_fp_multi)
'''initilize function unit'''
# 1 cycle in int adder 
fu_int_adder = deque()
time_fu_int_adder = 1
# 3 cycles in fp adder 
fu_fp_adder = deque()
time_fu_fp_adder = 4
# 20 cycles in fp multiplier
fu_fp_multi = deque()
time_fu_fp_multi = 15
'''initialize load/store queue'''
ld_sd_queue = deque()
size_ld_sd_queue = 5 
ld_sd_exe = ld_sd_exe()
ld_sd_exe.busy = 0
time_ld_sd_exe = 1
ld_sd_mem = ld_sd_mem()
ld_sd_mem.busy = 0
time_ld_sd_mem = 5
'''initialize ROB'''
ROB = deque()
size_ROB = 64
'''initialize CDB'''
results_buffer = deque()
cdb = cdb()
cdb.valid = 0
"""issue first instruction"""
# instruction pointer 
PC = PC()
PC.PC = 0
PC.valid = 1 
BTB = build_btb()
branch_predictions = {}
cycle = 1
recovery_resume_cycle = None
pending_recovery = None

# print title 
item = ''.ljust(30)
item += 'ISSUE'.ljust(15)
item += 'EXE'.ljust(15)
item += 'MEM'.ljust(15)
item += 'WB'.ljust(15)
item += 'COMMIT'.ljust(15)
print (item)

# main
while (len(ROB) > 0 or cycle == 1 or recovery_resume_cycle is not None):
    if (recovery_resume_cycle is not None and cycle >= recovery_resume_cycle):
        PC.valid = 1
        recovery_resume_cycle = None
    
    '''ISSUE stage'''
    if (PC.PC<len(instructions))&(PC.valid==1):
        issue(cycle, PC, instructions, ROB, size_ROB, 
                rs_int_adder, 
                rs_fp_adder, 
                rs_fp_multi, 
                ld_sd_queue, size_ld_sd_queue, 
                rat_int, rat_fp,BTB, branch_predictions,issue_width=issue_width)

    '''EXE stage'''
    exe(fu_int_adder, time_fu_int_adder, 
        fu_fp_adder, time_fu_fp_adder, 
        fu_fp_multi, time_fu_fp_multi, results_buffer,  
        rs_int_adder, rs_fp_adder, rs_fp_multi, 
        ld_sd_exe, time_ld_sd_exe, ld_sd_queue,
        cycle, ROB, PC, BTB, branch_predictions)
        # Capture a branch misprediction detected by exe().
    
    if '_recovery_pending' in branch_predictions:
        pending_recovery = branch_predictions.pop('_recovery_pending')
        PC.PC = pending_recovery['recovery_pc']
        recovery_resume_cycle = pending_recovery['detected_cycle'] + 2

        # Find the mispredicted branch in the ROB.
        branch_tag = pending_recovery['branch_tag']
        rob_entries = list(ROB)
        branch_index = next(
            (i for i, entry in enumerate(rob_entries)
             if entry.ROB_tag == branch_tag),
            None
        )

        if branch_index is None:
            raise RuntimeError(
                'Mispredicted branch not found in ROB: ' + str(branch_tag)
            )

        # Keep the branch and all older instructions.
        ROB.clear()
        ROB.extend(rob_entries[:branch_index + 1])
        surviving_tags = {entry.ROB_tag for entry in ROB}

        # Remove prediction records for instructions discarded during recovery.
        for tag in list(branch_predictions):
            if tag != '_recovery_pending' and tag not in surviving_tags:
                del branch_predictions[tag]

        # Rebuild RAT from committed registers and surviving ROB entries.
        print("RECOVERY branch:", branch_tag,
              "surviving:", [(e.ROB_tag, e.PC) for e in ROB])
        print("RAT before rebuild R1/R2:", rat_int[1:3])
        rat_int[:] = deepcopy(reg_int)
        rat_fp[:] = deepcopy(reg_fp)

        for entry in ROB:
            destination = entry.dest_tag

            if not isinstance(destination, str):
                continue

            if destination.startswith('R'):
                reg_index = int(destination[1:])
                if reg_index != 0:
                    rat_int[reg_index] = (
                        entry.value if entry.cdb else entry.ROB_tag
                    )

            elif destination.startswith('F'):
                reg_index = int(destination[1:])
                rat_fp[reg_index] = (
                    entry.value if entry.cdb else entry.ROB_tag
                )

        # Clear reservation stations belonging to discarded instructions.
        for rs in (rs_int_adder, rs_fp_adder, rs_fp_multi):
            for entry in rs:
                if entry.busy and entry.dest_tag not in surviving_tags:
                    entry.busy = 0
                    entry.op = None
                    entry.tag_1st = None
                    entry.value_1st = 0
                    entry.valid_1st = 0
                    entry.tag_2nd = None
                    entry.value_2nd = 0
                    entry.valid_2nd = 0
                    entry.dest_tag = None
                # Clear stale operand dependencies on discarded ROB tags.

        # Remove discarded instructions from functional-unit queues.
        fu_int_adder = deque(
            entry for entry in fu_int_adder
            if entry.dest_tag in surviving_tags
        )
        fu_fp_adder = deque(
            entry for entry in fu_fp_adder
            if entry.dest_tag in surviving_tags
        )
        fu_fp_multi = deque(
            entry for entry in fu_fp_multi
            if entry.dest_tag in surviving_tags
        )

        # Remove wrong-path load/store entries.
        ld_sd_queue = deque(
            entry for entry in ld_sd_queue
            if entry.dest_tag in surviving_tags
        )

        # Remove results from discarded instructions.
        results_buffer = deque(
            entry for entry in results_buffer
            if entry.dest_tag in surviving_tags
        )

        # Clear dedicated load/store execution if its instruction was discarded.
        # if (ld_sd_exe.busy and
        #         ld_sd_exe.dest_tag not in surviving_tags):
        if (ld_sd_exe.busy and not any(entry.ld_sd_tag == ld_sd_exe.dest_tag
                for entry in ld_sd_queue)):
            ld_sd_exe.busy = 0
            ld_sd_exe.cycle = 0
            ld_sd_exe.value1 = 0
            ld_sd_exe.value2 = 0
            ld_sd_exe.dest_tag = None

        if (ld_sd_mem.busy and
                ld_sd_mem.dest_tag not in surviving_tags):
            ld_sd_mem.busy = 0
            ld_sd_mem.cycle = 0
            ld_sd_mem.op = None
            ld_sd_mem.data = None
            ld_sd_mem.address = None
            ld_sd_mem.dest_tag = None


    '''MEM stage'''
    mem(ld_sd_queue, ld_sd_mem, time_ld_sd_mem, results_buffer,
        memory, ROB, cycle)

    '''CDB stage'''
    wb(cdb, rat_int, rat_fp, 
        rs_int_adder, rs_fp_adder, rs_fp_multi,
        ld_sd_queue, ROB, cycle,
        results_buffer) 
    
    '''COMMIT stage'''
    commit(ROB, reg_int, reg_fp, cycle, instructions,
       ld_sd_queue, memory)
    
    # cycle number 
    cycle +=1
    if cycle % 100 == 0:
        print("CYCLE:", cycle, "PC:", PC.PC)
        print("ROB:", [
            (e.ROB_tag, e.PC, e.dest_tag, e.exe, e.cdb, e.commit)
            for e in ROB
        ])
        print("LSQ:", [
            (e.ld_sd_tag, e.op, e.dest_tag, e.ready,
            e.address, e.data, e.reg_tag, e.valid)
            for e in ld_sd_queue
        ])
        print("RS INT:", [
            (e.busy, e.op, e.dest_tag, e.tag_1st, e.valid_1st,
            e.tag_2nd, e.valid_2nd)
            for e in rs_int_adder if e.busy
        ])

print("CHECK R1:", reg_int[1])
print("CHECK R2:", reg_int[2])
print("CHECK PC:", PC.PC)
print("CHECK ROB:", [(e.ROB_tag, e.PC) for e in ROB])
print("=================================================")
print("\nFINAL INTEGER REGISTERS")
for i, value in enumerate(reg_int):
    if value != 0:
        print(f"R{i} = {value}")

print("\nFINAL FLOATING-POINT REGISTERS")
for i, value in enumerate(reg_fp):
    if value != 0:
        print(f"F{i} = {value}")

print("\nFINAL MEMORY")
for address in range(0, len(memory), 4):
    if memory[address] != 0:
        print(f"Mem[{address}] = {memory[address]}")
    
